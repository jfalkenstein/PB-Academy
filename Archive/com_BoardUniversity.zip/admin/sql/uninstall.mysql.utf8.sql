/**
 * Author:  jfalkenstein
 * Created: Apr 4, 2016
 */

DROP TABLE IF EXISTS `#__CBUContentTypes`;
DROP TABLE IF EXISTS `#__CBUCategories`;
DROP TABLE IF EXISTS `#__CBULessons`;