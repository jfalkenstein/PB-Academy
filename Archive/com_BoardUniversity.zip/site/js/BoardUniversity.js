var hoverShadow = function(){
    var sbox = jQuery('.shadowbox');
    var hoverCSS = {
        border-radius: '10px',
        -moz-box-shadow: '0 0 10px black',
        -webkit-box-shadow: '0 0 10px black',
        box-shadow: '0 0 10px black'
    };
    var nonHoverCSS = {
        -mox-box-shadow: 'none',
        -webkit-box-shadow: 'none',
        box-shadow: 'none'
    };
    
    sbox.hover(function(e){
        sbox.animate(hoverCSS);
    }, function(e){
        e.animate(nonHoverCSS);
    });    
}

jQuery(document).ready(hoverShadow);