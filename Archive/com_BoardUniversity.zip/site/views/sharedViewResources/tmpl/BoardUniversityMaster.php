<div class="leftMenu">
    <h3><?php echo $this->MenuTitle ?></h3>
    <ul>
        <?php foreach($this->Categories as $cat) : ?>
        <li>
            <a href="<?php echo JRoute::_('index.php?option=com_boarduniversity'
                                                  . '&section=category'
                                                  . '&c_id=' . $cat->Id);?>">
            <?php 
            /* @var $cat _category */
            echo $cat->Name . '</a> (<span class="count">' . $cat->LessonCount() . '</span>)';
            ?>
        </li>
        <?php endforeach; ?>
    </ul>
</div>
<div class="mainBody">
    <h1 class="mainBodyTitle"><?php echo $this->PageTitle; ?></h1>
    <?php include $this->MainBodyInclude; ?>
</div>
<div class="NavBar">
    <?php
        if(isset($this->BotNavBarInclude)){
            include $this->BotNavBarInclude;
        }
    ?>
</div>