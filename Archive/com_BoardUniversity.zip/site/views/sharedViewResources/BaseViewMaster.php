<?php

/**
 * Description of BaseViewMaster
 * 
 * @author jfalkenstein
 * 
 */
abstract class BaseViewMaster extends JViewLegacy {
    public $MenuTitle;
    public $MainBodyInclude;
    protected $viewName;
    public $MasterTemplate;
    public $Categories;
    public $PageTitle;
    public $BotNavBarInclude;
    
    public function __construct($config = array()) {
        $this->viewName = $config['viewName'];
        $this->MenuTitle = 'Schools';
        $this->MainBodyInclude = __DIR__ . '/../' . $this->viewName . '/tmpl/MainBodyInclude.php';
        $this->MasterTemplate = 'tmpl/BoardUniversityMaster.php';
        parent::__construct($config);
    }
    
    public function display($tpl = null) {
        $this->setCategories();
        $this->setPageTitle();
        if(!is_null($tpl)){
            include $tpl;
        }else{
            include $this->MasterTemplate;
        }      
    }
    
    abstract protected function setCategories();
    abstract protected function setPageTitle();
}
