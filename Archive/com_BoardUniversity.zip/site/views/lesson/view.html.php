<?php
require_once __DIR__ . BASE_VIEW_INCLUDE_PATH;

class BoardUniversityViewLesson extends BaseViewMaster{
    
    public function display($tpl = null) {
        $this->ThisLesson = $this->get('Lesson','lesson');
        $this->BotNavBarInclude = 'NavBar.php';
        parent::display();
    }
    public function setCategories() {
        $this->Categories = $this->get('Categories','lesson');
    }
    public function setPageTitle() {
        $this->PageTitle = $this->ThisLesson->Title;
    }
}
