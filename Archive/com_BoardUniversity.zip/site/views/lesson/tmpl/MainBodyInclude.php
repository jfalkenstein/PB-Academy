<?php 
    /* @var $activeLesson Lesson */
    $activeLesson = $this->ThisLesson;
?>
<div id="MainLesson">
    <div id="LessonEmbed">
        <?php $activeLesson->PrintEmbedString();?>
    </div>
    <div id="PubDate">
        <span><?php echo $activeLesson->DatePublished ?></span>
    </div>
    <div id="LessonDescription">
        <p><?php echo $activeLesson->Description ?></p>
    </div>
</div>
