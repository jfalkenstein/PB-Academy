<?php 
/* @var $firstLesson Lesson */
$firstLesson = $this->RecentLessons[0];
?>
<div id="recentLessons">
    <div class="latestLesson">
        <h2>Most Recent Lessons:</h2>
        <h3 id="lastestTitle">
            <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                        . '&section=lesson'
                                        . '&l_id=' . $firstLesson->Id); ?>">
                <?php echo $firstLesson->Title ?>
            </a>
        </h3>
        <div class="shadowbox">
            <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                        . '&section=lesson'
                                        . '&l_id=' . $firstLesson->Id); ?>">
                <img src="<?php echo $firstLesson->ImagePath; ?>">
            </a>
        </div>
        <div class="lastestLessonDescrip"><?php echo $firstLesson->Description; ?></div>
        <div class="latestLessonCategory">From: 
            <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                        . '&section=category'
                                        . '&c_id=' . $firstLesson->Category->Id); ?>">
                <?php echo $firstLesson->Category->Name; ?>
            </a>
        </div>
    </div>
    <div id="otherRecentLessons">
        <?php 
            $count = 1;
            $columns = 3;
            for($i = 1; $i < count($this->RecentLessons);$i++) :
                /* @var $currentLesson Lesson */
                $currentLesson = $this->RecentLessons[$i];
                if($count % $columns == 1) : ?>
                    <div class="lessonRow">
                <?php endif; ?>
                <div class="lessonThumb" style="
                        width:<?php echo (100/$columns)- $columns; ?>%;">
                    <h3 class="thumbtitle">
                        <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                                    . '&section=lesson'
                                                    . '&l_id=' . $currentLesson->Id); ?>">
                            <?php echo $currentLesson->Title; ?>
                        </a>
                    </h3>
                    <div class="shadowbox">
                        <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                                    . '&section=lesson'
                                                    . '&l_id=' . $currentLesson->Id); ?>">
                            <img src="<?php echo $currentLesson->ImagePath; ?>">
                        </a>
                    </div>
                    <div class="thumbFooter">
                        <div class="thumbcategory">From:
                            <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                                        . '&section=category'
                                                        . '&c_id=' . $currentLesson->Category->Id); ?>">
                                <?php echo $currentLesson->Category->Name; ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php
                if($count % $columns == 0) : ?>
                    </div>
            <?php 
                endif;
                $count++;
            ?>
        <?php 
            endfor;
            if($count % $columns != 1) echo '</div>';
        ?>
    </div>
</div>
<div id="categories">
    <h2>Schools:</h2>
    <?php 
        $count = 1;
        $columns = 4;
        foreach($this->Categories as $cat) :
            /* @var $cat _category */
            if($count % $columns == 1) : ?> 
                <div class="catRow">
            <?php endif; ?>
                <div class="catThumb" style="
                     width:<?php echo (100/$columns)- $columns; ?>%;">
                    <div class="shadowbox">
                        <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                                    . '&section=category'
                                                    . '&c_id=' . $cat->Id); ?>">
                            <img src="<?php echo $cat->ImagePath; ?>">
                        </a>
                    </div>
                    <div class="catFooter">
                        <a href="<?php echo JRoute::_(BOARD_UNIVERSITY
                                                    . '&section=category'
                                . '&c_id=' . $cat->Id);?>">
                                <?php echo $cat->Name; ?>
                        </a>
                    </div>
                </div>
            <?php
            if($count % $columns == 0) : ?>
                </div>
            <?php 
                endif;
                $count++;
            ?>
        <?php 
            endforeach; 
            if($count % $columns != 1) echo '</div>';
        ?>
</div>