<?php
require_once __DIR__ . BASE_VIEW_INCLUDE_PATH;
/**
 * Description of view
 *
 * @author jfalkenstein
 */
class BoardUniversityViewHome extends BaseViewMaster{
    
    public function display($tpl = null) {
        $this->RecentLessons = $this->get('RecentLessons','home');
        parent::display();
    }    
    public function setCategories() {
        $this->Categories = $this->get('Categories','home');
    }
    public function setPageTitle() {
        $this->PageTitle = 'Church Board University';
    }
}
