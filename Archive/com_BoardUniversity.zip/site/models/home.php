<?php
require_once 'shared.php';
class BoardUniversityModelHome extends BoardUniversityModelShared
{    
    private $recentLessonNum;
    public function __construct($config = array()) {
        if(isset($config['lessons'])){
            $this->recentLessonNum = $config['lessons'];
        }else{
            $this->recentLessonNum = 4;
        }
        parent::__construct($config);
    }
    
    public function getRecentLessons(){
        return $this->boardUManager->GetRecentLessons($this->recentLessonNum);
    }    
}
