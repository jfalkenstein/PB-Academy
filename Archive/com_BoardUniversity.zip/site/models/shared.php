<?php

/**
 * Description of shared
 *
 * @author jfalkenstein
 */

require_once __DIR__.'/../classes/BoardUManager.php';

abstract class BoardUniversityModelShared extends JModelLegacy {
    /* @var $boardUManager BoardUManager */
    protected $boardUManager;
    
    public function __construct($config = array()) {
        $this->boardUManager = BoardUManager::GetInstance();
        parent::__construct($config);
    }
    
    public function getCategories(){
        return $this->boardUManager->GetAllCategories();
    }
}
