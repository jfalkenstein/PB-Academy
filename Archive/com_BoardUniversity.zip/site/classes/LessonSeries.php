<?php

/**
 * Description of LessonSeries
 *
 * @author jfalkenstein
 */
class LessonSeries {
    //put your code here
}
