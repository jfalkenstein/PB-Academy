<?php

/**
 * Class: BoardUManager
 * 
 * This class functions as the top-level interface for all the Church Board University
 * core classes and methods. It "knows" what needs to be done in order to implement the various
 * actions the various classes can do.
 * 
 * BoardUManager implements the singleton pattern, thus making sure that the list of $allcategories
 * remains accurate. This helps reduce the number of db queries that are necessary.
 * 
 * To use this class, you need to obtain the singleton instance through GetInstance.
 * 
 * @property []string $ErrorMessages 
 * This is the sole public property of BoardUManager. It can be checked to ensure
 * no errors have cropped up. If so, they will be reported. Otherwise, it will remain empty.
 * 
 * @author jfalkenstein
 */

require_once 'Categories.php';
require_once 'Lesson.php';
require_once 'LessonSeries.php';
require_once 'ContentTypes.php';

class BoardUManager {
    private static $instance;
    private $allCategories = [];
    public $ErrorMessages;
    
    /**
     * GetInstance:
     * This is the main gateway to obtaining an instance of the BoardUManager.
     * It enforces a singleton pattern to reduce db queries.
     * @return BoardUManager
     */
    public static function GetInstance(){
        if(!isset(self::$instance)){
            self::$instance = new BoardUManager();
        }
        return self::$instance;
    }
    
    /**
     * This method will load all categories into the private $allCategories field.
     */
    private function loadAllCategories(){
        $this->allCategories = Categories::GetAll();
    }
    
    /**
     * GetAllCategories:
     * This is the way the complete list of categories should be obtained. It will
     * stay updated as changes are made, but will not require repeated db queries
     * when the category list hasn't changed.
     * @return []_category
     */
    public function GetAllCategories(){
        if(count($this->allCategories) === 0){
            $this->loadAllCategories();
        }
        return $this->allCategories;
    }
    
    /**
     * GetCategory:
     * This will return the category with the specified name from.
     * If unable to return a value, it will return the default.
     * @param string $name - The name of the category
     * @param mixed $default - The default return value if the category isn't found.
     * @return _category
     */
    public function GetCategory($name, $default = null){
        return Categories::GetByName($name, $default);
    }
    
    /**
     * This will create a category and save it to the database. It will return the new
     * category if it created successfully.
     * @param string $name The name of the new category.
     * @param type $imagePath The path to the image that represents this category.
     * @return _category
     */
    public function CreateCategory($name, $imagePath = null){
        try{
            $newCat = Categories::CreateNew($name, $imagePath);
            if(is_null($newCat)){
            $this->ErrorMessages[] = 'There was an error creating the category '
                    . 'named ' . $name;
            }
            $this->loadAllCategories();
            return $newCat;
        } catch (Exception $ex) {
            $this->ErrorMessages[] = $ex->getMessage();
        }
    }
    
    /**
     * This deletes the passed in category. It is essential that this category has
     * a valid Id; Otherwise, an exception will be thrown.
     * @param _category $categoryWithId
     * @throws Exception
     */
    public function DeleteCategory($categoryWithId){
        try{
            $success = Categories::DeleteCategory($categoryWithId);
            if(!$success){
                throw new Exception('There was a problem deleting the category.');
            }
        } catch (Exception $ex) {
            $this->ErrorMessages[] = $ex->getMessage();
        }
        $this->loadAllCategories();
    }
    
    /**
     * This will update the category with the specified id and then save those changes
     * to the database.
     * @param int $id - The Id of the category to be updated.
     * @param string $name - The NEW name of the category; if null, the original name will remain.
     * @param string $description - The NEW description; if null, original will remain.
     * @param type $imagePath - The NEW imagePath; if null, original will remain.
     */
    public function UpdateCategory($id, $name = null, $description = null, $imagePath = null){
        $oldCat = Categories::GetByID($id);
        /* @var $oldCat _category */
        if(is_null($oldCat)){
            $this->ErrorMessages[] = 'Unable to locate the category with the id of ' . $id;
        }else{
            $oldCat->Name = (($name) ? $name : $oldCat->Name);
            $oldCat->Description = (($description) ? $description : $oldCat->Description);
            $oldCat->ImagePath = (($imagePath) ? $imagePath : $oldCat->ImagePath);
            $oldCat->Save(true);
            $this->loadAllCategories();
        }
    }
    
    /**
     * This will obtain the lesson identified by the id from the db. If it cannot
     * be found, it will return the specified $default value.
     * @param int $id - The id of the lesson desired.
     * @param mixed $default - The value to return if the lesson cannot be found. 
     * @return Lesson
     */
    public function GetLesson($id, $default = null){
        return Lesson::GetLessonById($id, $default);
    }
    
    /**
     * This will obtain an array of the most recent lessons, with the quanity of
     * whatever number is specified, or the max available--whichever is lesser.
     * @param int $numberToGet
     * @return []Lesson
     */
    public function GetRecentLessons($numberToGet = 4){
        return Lesson::GetRecentLessons($numberToGet);
    }
    
    /**
     * This will create and save a new lesson.
     * @param _contentType $contentType
     * @param string $title
     * @param _category $category
     * @param string $datePublished
     * @param string $description
     * @param string $content
     * @param string $series - THIS WILL BECOME A SERIES OBJECT ONCE IMPLEMENTED
     * @param string $imagePath
     * @param string $sourceCredit
     * @return type
     */
    public function CreateLession($contentType,
                                $title, 
                                $category,
                                $datePublished = null,
                                $description = null,
                                $content = null,
                                $series = null, 
                                $imagePath = null, 
                                $sourceCredit = null){
        if(!$contentType instanceof _contentType){
            $this->ErrorMessages[] = 'You must input a valid ContentType';
        }elseif (!$category instanceof _category) {
            $this->ErrorMessages[] = 'You must input a valid category object.';
        }else{
            $les = new Lesson(
                    $contentType, 
                    $title,
                    $category,
                    $description,
                    null,
                    $content,
                    $series,
                    $imagePath,
                    $sourceCredit,
                    $datePublished);
            $success = $les->Save();
            if(!$success){
                $this->ErrorMessages[] = 'There was a problem saving the new lesson.';
            }
        } 
    }
    
    /**
     * DeleteLesson:
     * This will obtain the specified lesson, then call its delete method to remove it from
     * the database.
     * @param int $id - The id of the lesson you desire to use.
     */
    public function DeleteLession($id){
        $les = Lesson::GetLessonById($id);
        /* @var $les Lesson */
        if(!is_null($les)){
            $les->Delete();
        }
    }
    
    public function GetSeries(){
        
    }
    
    public function CreateSeries(){
        
    }
    
    public function DeleteSeries(){
        
    }
    
    public function UpdateSeries(){
        
    }
            
}
