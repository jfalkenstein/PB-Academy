<?php

/**
 * Description of Category
 *
 * @author jfalkenstein
 */
class Categories {
    private static $categories = [];
    
    public static function GetByName($name, $default = null){
        //1. Make searched name lowercase
        $name = strtolower($name);
        //2. get all categories
        $cats = self::GetAll();
        //3. Check if category exists. If so, get it.
        $category = ((isset($cats[$name])) ? $cats[$name] : $default);
        //4. Return the value
        return $category;
    }
    
    public static function GetByID($id, $default = null){
        foreach(self::GetAll() as $category){
            /* @var $category _category */
            if($category->Id === $id){
                return $category;
            }
        }
        return $default;
    }
    
    public static function GetAll(){
        if(count(self::$categories)=== 0){
            self::loadCategoriesFromDb();
        }
        return self::$categories;
    }
    
    
    public static function CreateNew($name, $imagePath = null){
        //1. Check if it already exists
        if(!is_null(self::GetByName($name))){
            return null;
        }else{ 
            try{
                //2. Instantiate a new category
                $newCat = new _category();
                $newCat->Name = $name;
                $newCat->ImagePath = $imagePath;
                //3. Save the new category.
                $newCat->Save(); 
                //4. reload list of categories form the DB.
                self::loadCategoriesFromDb();
                //5. Return the newly created category.
                return self::GetByName($name);
            } catch (Exception $ex) {
                return null;
            }
        }
    } 
    
    public static function DeleteCategory($categoryWithId){
        /* @var $categoryWithId _category */
        //1. Check if category is instance of _category and it has the $id
        //property set.
        
        if(!$categoryWithId instanceof _category){
            throw new Exception('You must use a valid category as a parameter');
        }elseif (!isset($categoryWithId->Id)){
            throw new Exception('The category must have the $Id property set in order'
                    . 'to delete it.');
        }
        //2. Delete all lessons associated with this category.
        foreach($categoryWithId->GetLessions() as $lesson){
            /* @var $lesson Lesson */
            $success = $lesson->Delete();
            if(!$success){
                throw new Exception('Unable to delete all lessons, therefore could not'
                        . 'delete the category.');
            }
        }
        //3. Delete this category from the db.
        $success = $categoryWithId->Delete();
        return $success;
    }
    
    private static function loadCategoriesFromDb(){
        //1. Query the db for all categories.
        $rawCats = self::getRawCategoriesFromDb();
        
        //2. For each category, instantiate a new _category
        foreach($rawCats as $cat){
            self::$categories[strtolower($cat->Name)] = new _category(
                    $cat->Name,
                    $cat->Description,
                    $cat->Id,
                    $cat->ImagePath);
        }
        
    }
    
    private static function getRawCategoriesFromDb(){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*')
                ->from($db->quoteName('#__CBUCategories'));
        $db->setQuery($query);
        $results = $db->loadObjectList();
        return $results;
    }
}

class _category{
    public $Id;
    public $Name;
    public $Description;
    public $ImagePath;
    private $lessons = [];
    private $lessonCount;
    
    public function __construct($name, 
                                $description = null,
                                $id = null,
                                $imagePath = null){
        $this->Name = $name;
        $this->Description = $description;
        $this->Id = $id;
        $this->ImagePath = $imagePath;
    }
    
    public function LessonCount(){
        if(!isset($this->lessonCount)){
            $this->loadLessonsFromDb();
            $this->lessonCount = count($this->lessons);
        }
        return $this->lessonCount;
    }
    
    public function GetLessions(){
        $this->loadLessonsFromDb();
        if(count($this->lessons) === 0){
            return 0;
        }else{
            return $this->lessons;
        }
    }
    
    private function loadLessonsFromDb(){
        $this->lessons = Lesson::GetLessonsForCategory($this->Id);
    }
    
    private function getRawLessons(){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->select('*')
                ->from($db->quoteName('#__CBULessons','l'))
                ->leftJoin(
                        $db->quoteName('#__CBUCategories','c') . 
                        ' ON (' . 
                            $db->quoteName('l.CategoryId') . 
                            ' = ' . 
                            $db->quoteName('c.Id') . 
                        ')'
                        )
                ->leftJoin(
                        $db->quoteName('#__CBUContentTypes','ct') . 
                        ' ON (' .
                            $db->quoteName('l.ContentTypeId') . 
                            ' = ' . 
                            $db->quoteName('ct.Id') . 
                        ')'
                        );
        
        $db->setQuery($query);
        return (array)$db->loadObjectList($db->quoteName('l.Title'));
    }
    
    public function Save($update = FALSE){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $object = new stdClass();
        $object->Id = $this->Id;
        $object->Name = $this->Name;
        $object->Description = $this->Description;
        $object->ImagePath = $this->ImagePath;
        if($update){
            if(isset($this->Id)){
                $db->updateObject($db->quoteName('#__CBUCategories'),$object,$this->Id);
            }else{
                throw new Exception("You can only update a category is already in the database");
            };
        }else{
            $db->insertObject($db->quoteName('#__CBUCategories'),$object);
        };
    }
    
    public function Delete(){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->delete($db->quoteName('#__CBUCategories'))
                ->where($db->quoteName('Id') . ' = ' . $this->Id);
        $db->setQuery($query);
        $success = $db->execute();
        return $success;
    }
}