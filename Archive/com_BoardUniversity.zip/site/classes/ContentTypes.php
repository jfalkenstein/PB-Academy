<?php

/**
 * Description of ContentTypes
 *
 * @author jfalkenstein
 */
class ContentTypes 
{
    private static $instance;
    public $AllTypes = [];
    
    
    private function __construct(){
        foreach(self::getContentTypesFromDb() as $name=>$value){
            $this->{strtolower($name)} = new _contentType($name, $value);
            $this->AllTypes[$name] = $this->{strtolower($name)};
        }
    }
    
    public function __get($name){
        return $this->{strtolower($name)};
    }
    
    public static function GetInstance(){
        if(is_null(self::$instance)){
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    
    private static function getContentTypesFromDb(){
        $db = JFactory::getDbo();
        $query = $db->getQuery();
        $query->select('*')->from($db->quoteName('#__CBUContentTypes'));
        $db->setQuery($query);
        $results = $db->loadObjectList();
        $types;
        foreach($results as $ct){
            $types[$ct->TypeName] = new _contentType($ct->TypeName, $ct->Id); 
        }
        return $types;
    }
}

class _contentType{
    public $Name;
    public $Id;
    
    public function __construct($name, $id){
        $this->Name = $name;
        $this->Id = $id;
    }
}