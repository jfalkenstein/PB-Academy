<?php

/**
 * Description of LessonEmbedder
 *
 * @author jfalkenstein
 */
class LessonEmbedder{
    
    /**
     * BrainShark:
     * This method receives the current BrainShark Address and will return an embed code
     * for that BrainShark to be used on a lesson Page.
     * 
     * @param string $bSharkAddress
     * @return string The embed code for the BrainShark.
     */
    public static function BrainShark($bSharkAddress){
        $width = 555;
        $height = 348;
        $code = '<div class="video-container" style="padding-bottom:' . (($height/$width)*100). '%">'
                . '<iframe src="' . $bSharkAddress 
                  . '?dm=5&pause=1&nrs=1" frameborder="0" '
                  . 'width="'. $width . '" height="' . $height . '" scrolling="no" '
                  . 'style="border:1px solid #999999">'
                . '</iframe>'
                . '</div>';
        return $code;
    }
}