<?php

require_once 'ContentTypes.php';
require_once 'LessonEmbedder.php';

/**
 * @property _category $Category This is the category to which this lesson belongs.
 */
class Lesson{
    private $contentType;
    public $Id;
    public $Title; 
    public $Series; //Of type Series
    public $Category; //of type Category
    public $ImagePath; //Path to cover image
    public $SourceCredit; //If sourced externally
    public $Content; //various string representation, depending on contentType. - can include html
    public $Description; //string description - can include html content
    public $DatePublished; //date
    
    
    public function __construct($contentType, 
                                $title, 
                                $category,
                                $description = '',
                                $id = null,
                                $content = null,
                                $series = null, 
                                $imagePath = null, 
                                $sourceCredit = null,
                                $datePublished = null){
        if(!$contentType instanceof _contentType){
            throw new Exception("Invalid Content Type.");
        }
        if(!$category instanceof _category){
            throw new Exception("Invalid Category.");
        }
        $this->contentType = $contentType;
        $this->Title = $title;
        $this->Series = $series;
        $this->Category = $category;
        $this->ImagePath = $imagePath;
        $this->SourceCredit = $sourceCredit;
        $this->Content = $content;
        $this->Description = $description;
        $this->DatePublished = $datePublished;
        $this->Id = $id;
    }
    /**
     * This is the read-only ContentType that describes this lesson.
     * @return _contentType
     */
    public function ContentType(){
        return $this->contentType;
    }
    
    public static function GetLessonById($id, $default = null){
        //1. Get lesson record joined with its content type from the db.
        $rawLesson = self::getRawLessonFromDb($id);
        if(is_null($rawLesson)){
            return $default;
        }else{
            //2. Instantiate the lesson, also instantiating and assigning its 
            //category and ContentType
            $les = self::convertRawLesson($rawLesson);
            return $les;
        }
    }
    
    /**
     * GetLessonsForCategory:
     * This will return an array of all the lessons for a given categoryID.
     * @param int $catId
     * @return []Lesson
     */
    public static function GetLessonsForCategory($catId){
        $lessons = [];
        $db = JFactory::getDbo();
        $query = self::getQueryForAllLessons($db);
        $query->where($db->quoteName('l.CategoryId'). ' = ' . $catId);
        $db->setQuery($query);
        $results = $db->loadObjectList();
        foreach($results as $les){
            $lessons[] = self::convertRawLesson($les);
        }
        return $lessons;
    }
    
    /**
     * GetRecentLessons:
     * This static method will return the specified number of Lessons
     *  most recently published, or the maximum available.
     * @param int $numberToGet
     * @return []Lesson - An array of Lesson.
     */
    public static function GetRecentLessons($numberToGet = 4){
        $recentLessons = [];
        $db = JFactory::getDbo();
        $query = self::getQueryForAllLessons($db);
        $query->order($db->quoteName('Id'). ' DESC');
        $db->setQuery($query,0,$numberToGet);
        $results = $db->loadObjectList();
        foreach($results as $les){
            $recentLessons[] = self::convertRawLesson($les);
        }
        return $recentLessons;
    }
    
    /**
     * getQueryForAllLessons:
     * This method is a shortcut for the complicated join query required to pull
     * all lessons. 
     * @param JDatabaseDriver $db - A db object obtained through JFactory.
     * @return JDatabaseQuery - The loaded query object
     */
    private static function getQueryForAllLessons(&$db){
        $query = $db->getQuery(true);
        $query->select(['l.*','ct.TypeName','c.Name','c.Description AS CatDescription','c.ImagePath AS CatImagePath'])
                ->from($db->quoteName('#__CBULessons','l'))
                ->leftJoin(
                        $db->quoteName('#__CBUContentTypes','ct') . 
                        ' ON (' .
                            $db->quoteName('l.ContentTypeId') . 
                            ' = ' .
                            $db->quoteName('ct.Id') . 
                            ')'
                )
                ->leftJoin(
                        $db->quoteName('#__CBUCategories','c') .
                        ' ON (' .
                            $db->quoteName('l.CategoryId') .
                            ' = ' .
                            $db->quoteName('c.Id') .
                            ')'
                    );
        return $query;
    }
     
    private static function convertRawLesson($rawObjectFromDb){
        $cat = new _category(
                    $rawObjectFromDb->Name,
                    $rawObjectFromDb->CatDescription,
                    $rawObjectFromDb->CategoryId,
                    $rawObjectFromDb->CatImagePath);
        $ct = new _contentType(
                $rawObjectFromDb->TypeName, 
                $rawObjectFromDb->ContentTypeId);
        $les = new Lesson(
                $ct,
                $rawObjectFromDb->Title,
                $cat,
                $rawObjectFromDb->Description,
                $rawObjectFromDb->Id,
                $rawObjectFromDb->Content,
                $rawObjectFromDb->SeriesId,
                $rawObjectFromDb->ImagePath,
                $rawObjectFromDb->SourceCredit,
                $rawObjectFromDb->DatePublished);
        return $les;
    }
    
    private static function getRawLessonFromDb($id){
        $db = JFactory::getDbo();
        $query = self::getQueryForAllLessons($db);
        $query->where($db->quoteName('l.Id') . ' = ' . $id);
        $db->setQuery($query);
        $results = $db->loadObject();
        return $results;        
    }
    
    public function Save($update = FALSE){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $object = new stdClass();
        $object->Id = $this->Id;
        $object->Title = $this->Title;
        //$object->SeriesId = $this->Series->Id THIS WILL BE ADDED WHEN SERIES FUNCTIONALITY IS ADDED
        $object->CategoryId = $this->Category->Id;
        $object->ContentTypeId = $this->ContentType()->Id;
        $object->ImagePath = $this->ImagePath;
        $object->SourceCredit = $this->SourceCredit;
        $object->Content = $this->Content;
        $object->Description = $this->Description;
        $object->DatePublished = $this->DatePublished;
        if($update){
            $success = $db->updateObject($db->quoteName('#__CBULessons'),$object,$this->Id);
        }else{
            $success = $db->insertObject($db->quoteName('#__CBULessons'),$object,$this->Id);
        }
        return $success;
    }
    
    public function Delete(){
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->delete($db->quoteName('#__CBULessons'))
                ->where($db->quoteName('Id') . ' = ' . $this->Id);
        $db->setQuery($query);
        $success = $db->execute();
        return $success;
    }
    
    /**
     * PrintEmbedString:
     * This method will return the html string to embed the contentType into the lesson page.
     * It switechs on the contentType for this lesson, functioning differently depending on
     * the particular contentType.
     * 
     * The raw material for the returned embed code comes from the content property.
     * 
     * @return string The html embed code to be used in the Lesson Page.
     */
    public function PrintEmbedString(){
        switch($this->contentType->Id){
            case 1: //BrainShark -> Create embed code from brainshark Id
                echo LessonEmbedder::BrainShark($this->Content);
                break;
            case 2: //GenericVideo -> insert(or create?) embed code from content
                break;
            case 3: //Download -> Create image of document that links to a file on our server
                break;
            case 5: //Youtube -> Create Youtube embed code from youtube link
                break;
            default: //Html -> Return raw html string from content, stripped of script tags.
                break;
        }
    }
}

