<?php

class BoardUniversityController extends JControllerLegacy
{           
    private $configArray;
    
    public function home($cachable = false, $urlparams = array()) {
        $this->configArray['viewName'] = 'home';
        $homeView = $this->getView('home','html','',$this->configArray);
        $homeView->setModel($this->getNamedModel('home'));
        $homeView->display();
    }
    
    public function category(){
        $input = JFactory::getApplication()->input;
        $catID = $input->getInt('c_id');
        $this->configArray['catID'] = $catID;
        if($catID){
            $this->configArray['viewName'] = 'category';
            echo 'Going to a category #' . $catID;
            //1. Load the model
            //2. Load the view
        }else{
            $this->configArray['viewName'] = 'catIndex';
            echo 'Going to all categories page';
            //1. Load the model
            //2. Load the view
        }
    }
    
    public function series(){
        //1. Load the model
        //2. Load the view
    }
    
    public function lesson(){
        $input = JFactory::getApplication()->input;
        $lessonId = $input->getInt('l_id');
        if($lessonId){
            $this->configArray['lessonId'] = $lessonId;
            $this->configArray['viewName'] = 'lesson';
            $lessonView = $this->getView('lesson', 'html','',$this->configArray);
            $lessonView->setModel($this->getNamedModel('lesson'));
            $lessonView->display();
        }else{
            echo 'Going to lesson index page.';
        }
    }
    
    public function getNamedModel($modelName, $className = null){
        require_once 'models/' . $modelName . '.php';
        $class = (($className) ? $className : 'BoardUniversityModel' . ucfirst($modelName));
        return new $class($this->configArray);
    }
    
}