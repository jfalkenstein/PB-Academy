<?php
error_reporting(E_ALL);
defined('_JEXEC') or die("Restricted Access");

const BOARD_UNIVERSITY = 'index.php?option=com_boarduniversity';
const BASE_VIEW_INCLUDE_PATH = '/../sharedViewResources/BaseViewMaster.php';

$app = JFactory::getApplication();
$doc = JFactory::getDocument();
$doc->addStyleSheet('/components/com_boarduniversity/css/BoardUniversity.css');
//$doc->addScript('/components/com_boarduniversity/js/BoardUniversity.js');
$input = $app->input;
$controller = JControllerLegacy::getInstance('BoardUniversity');
$controller->execute($input->getCmd('section','home'));
$controller->redirect();

