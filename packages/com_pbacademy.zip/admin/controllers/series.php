<?php

/**
 * Description of series
 *
 * @author jfalkenstein
 */
class series {
    //put your code here
}
