<?php

/**
 * Description of category
 *
 * @author jfalkenstein
 */
class category {
    //put your code here
}
