<?php

/**
 * This class handles the AJAX requests for Lessons.
 *
 * @author jfalkenstein
 * @property PBAcademyManager $PBAcademyManager Description
 */
class lessonController extends BaseController{

    public function pullAll(){
        $lessons = $this->PBAcademyManager->GetAllLessons();
        array_walk($lessons, function(&$item){
                /* @var $item Lesson */
                $item->Date = $item->DatePublished();
                $item->TruePosition = $item->TrueSeriesPosition();
        });
        $doc = JFactory::getDocument();
        $doc->setMimeEncoding('application/json');
        JResponse::setHeader('Content-Disposition','attachment;filename="result.json"');
        echo json_encode($lessons);
        JFactory::getApplication()->close();
    }
}
