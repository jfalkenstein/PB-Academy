<?php

/**
 * Description of BaseController
 *
 * @author jfalkenstein
 */
class BaseController extends JControllerLegacy {
    public $PBAcademyManager;
    
    public function __construct($config = array()) {
        $this->PBAcademyManager = PBAcademyManager::GetInstance();
        parent::__construct($config);
    }
}
