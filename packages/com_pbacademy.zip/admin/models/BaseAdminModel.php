<?php

require_once PB_ACADEMY_LIB . '/PBAcademyManager.php';

/**
 * @property PBAcademyManager $pbAcademyManager
 */
abstract class BaseAdminModel extends JModelLegacy
{
    public $pbAcademyManager;
    private $allCategories;
    private $allSeries;
    
    public function __construct($config = array()) {
        $this->pbAcademyManager = PBAcademyManager::GetInstance();
        parent::__construct($config);
    }
    
    public function getAllCategories(){
        return $this->pbAcademyManager->GetAllCategories();
    }
    
    public function getAllSeries(){
        if(is_null($this->allSeries)){
            $this->allSeries = $this->pbAcademyManager->GetAllSeries();
            array_walk($this->allSeries, function(&$item){
                /* @var $item LessonSeries */
                $item->Lessons = $item->GetLessons;
                $item->LessonsCount = $item->LessonCount();
            });
        }
        return $this->allSeries;
    }
    
}
