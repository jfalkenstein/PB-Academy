<?php

/**
 * Description of lesson
 *
 * @author jfalkenstein
 */
class PbAcademyModelLesson extends BaseAdminModel{
    
    public $LessonId;
    
    public function __construct($config = array()) {
        if(isset($config['id'])){
            $this->LessonId = $config['id'];
        }
        parent::__construct($config);
    }
    
    /**
     * 
     * @return Lesson
     */
    public function getLesson(){
        return $this->pbAcademyManager->GetLesson($this->LessonId);
    }
}
