<div id="topMenu">
    <div class="menuBarButton pbButton" id="manageLessons"><a href="#" onclick="tabToggle('manageLessons')">Manage Lessons</a></div>
    <div class="menuBarButton pbButton" id="manageSeries"><a href="#" onclick="tabToggle('manageSeries')">Manage Series</a></div>
    <div class="menuBarButton pbButton" id="manageCategories"><a href="#" onclick="tabToggle('manageCategories')">Manage Schools</a></div>
</div>
<div class="manageTab" id="lessonsDiv">
    <a 
        class="addButton pbButton" 
        href="<?php echo AdminUrlMaker::AddEditLesson(); ?>">
            <span class="icon-plus"></span>
            Add new Lesson
    </a>
    <br/>
    <a 
        class="loadLink pbButton" 
        href="#" 
        onclick="fillTableFromCBU('<?php echo AdminUrlMaker::AjaxAllLessons()?>', 'lessonsDiv')">
        <span class="icon-list"></span>View All Lessons
    </a>
</div>
<div class="manageTab" id="seriesDiv">
series
</div>
<div class="manageTab" id="categoriesDiv">
cats
</div>
