<?php

/**
 * Description of view
 *
 * @author jfalkenstein
 */
class PbAcademyViewAdminHome extends BaseAdminViewMaster{
    
    public $AllLessons;
    
    public function setPageTitle() {
        $this->PageTitle = 'P&B Academy Back End';
    }
    
    
    
}
