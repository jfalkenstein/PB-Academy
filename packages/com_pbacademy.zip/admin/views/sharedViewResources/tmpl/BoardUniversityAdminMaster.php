<?php /* @var $this BaseViewMaster */ ?>
<div class="mainBody">
    <h1 id="mainBodyTitle"><?php echo $this->PageTitle; ?></h1>
    <?php include $this->MainBodyInclude; ?>
</div>
<div class="adminMenu">
    <ul>
        <li><a href="<?php echo AdminUrlMaker::ManageHome()?>">Manage Items</a></li>
    </ul>
</div>
