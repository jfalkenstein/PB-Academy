<?php 
/* @var $this PbAcademyViewAddEditLesson */ 
$ThisLesson = $this->Lesson;
$ContentTypes = ContentTypes::GetInstance();
$AllCategories = $this->AllCategories;
$AllSeries = $this->AllSeries;
?>

<script>
    var AllSeries = JSON.parse('<?php echo json_encode($AllSeries)?>');
</script>
<p>This is where you can add or update a lesson.</p>
<form action="<?php echo AdminUrlMaker::AjaxPostLesson();?>" onsubmit="postNewLesson();" onload="setSeries();">
    <input type="hidden" name="lessonId" value="<?php echo(($ThisLesson) ? $ThisLesson->Id : ''); ?>">
    <label for="title">Title:</label><input type="text" name="title" maxlength="250" value="<?php echo(($ThisLesson) ? $ThisLesson->Title : ''); ?>" required>
    <label for="description">Description:</label><textarea name="description" rows="5" cols="50" maxlength="250" required><?php echo(($ThisLesson) ? $ThisLesson->Description : '');?></textarea>
    <label for="credit">Source Credit:</label><input type="text" name="credit" maxlength="250" value="<?php echo(($ThisLesson) ? $ThisLesson->SourceCredit : ''); ?>">
    <label for="contentTypeId">Select the type of content you desire:</label>
    <select id="contentTypeDropDown" name="contentTypeId" required>
        <option value="" selected>Select a Content Type</option>
        <?php foreach($ContentTypes->AllTypes as $type) :
            /* @var $type _contentType */?>
        <option value ="<?php echo $type->Id; ?>"><?php echo $type->Name; ?></option>
        <?php endforeach; ?>
    </select>
    <div id="contentSpot"></div>
    <label for="category">Select the school this lesson belongs to.</label>
    <select name="category" required>
        <?php foreach($AllCategories as $cat) : 
        /* @var $cat _category */ ?>
        <option 
            value="<?php echo $cat->Id ?>" 
            <?php if($cat->Id == $ThisLesson->Category->Id): ?>
            selected
            <?php endif; ?>>
                <?php echo $cat->Name;?>
        </option>
        <?php endforeach; ?>
    </select>
    <label for="series">Select the series (if any) that this belongs to.</label>
    <select id="seriesDrop" name="series">
        <?php foreach($AllSeries as $ser) : 
        /* @var $ser LessonSeries */?>
        <option
            value="<?php echo $ser->Id; ?>"
            <?php if($ser->Id == $ThisLesson->Series->Id) : ?>
            selected 
            <?php endif;?>>
                <?php echo $ser->SeriesName; ?>
        </option>
        <?php endforeach;?>
    </select>
    <div id="SeriesOrder">
        <label for="position">Select the position in the series.</label>
        <select id="seriesPosition" name='position'>
            
        </select>
    </div>
    <input type="submit">
</form>



<div class="contentForm" id="content-1">
    <!--BrainShark Embed-->
    <label for="content">Please copy below the BrainShark address.
        <br/> 
        Example:<span class="example">https://www.brainshark.com/pbusa/retirement_transition</span>
        <br/>
    </label>
    <input type="text" name="content" value="<?php echo(($ThisLesson) ? $ThisLesson->Content : ''); ?>">
</div>

<div class="contentForm" id="content-2">
    <!--Generic Video Embed-->
    <label for="content">Please copy below the embed code for the video you desire.
        <br/> 
    </label>
    <textarea rows="5" cols="4" name="content"><?php echo(($ThisLesson) ? $ThisLesson->Content : ''); ?></textarea>
</div>

<div class="contentForm" id="content-3">
    <!--Download Link Embed-->
    <label for="content">Please enter below the link to the file you desire to make available for download.
        <br/> 
        Example: <span class="example">/resources/news/mydocument.pdf</span>
        <br/>
    </label>
    <input type="text" name="content" value="<?php echo(($ThisLesson) ? $ThisLesson->Content : ''); ?>">
</div>

<div class="contentForm" id="content-4">
    <!--Youtube Link Embed-->
    <label for="content">Please enter below the full YouTube video url.
        <br/> 
        Example: <span class="example">https://www.youtube.com/watch?v=z_ZuDHD2FHo</span>
        <br/>
    </label>
    <input type="text" name="content" value="<?php echo(($ThisLesson) ? $ThisLesson->Content : ''); ?>">
</div>

<div class="contentForm" id="content-6">
    <!--Naz Media Library Link Embed-->
    <label for="content">Please enter below the "permalink" from the Nazarene Media Library video you wish to post.
        <br/> 
        Example: <span class="example">http://medialibrary.nazarene.org/media/nyc-2015-kingdom</span>
        <br/>
    </label>
    <input type="text" name="content" value="<?php echo(($ThisLesson) ? $ThisLesson->Content : ''); ?>">
</div>

<div class="contentForm" id="content-5">
    <!--Raw html Embed-->
    <label for="content">Please enter below the "permalink" from the Nazarene Media Library video you wish to post.
        <br/> 
        Example: <span class="example">http://medialibrary.nazarene.org/media/nyc-2015-kingdom</span>
        <br/>
    </label>
    <?php
    $editor = &JFactory::getEditor();
    echo $editor->display(
            'content',
            ($ThisLesson) ? $ThisLesson->Content : '',
            '400',
            '400',
            '20',
            '20');
    ?>
</div>