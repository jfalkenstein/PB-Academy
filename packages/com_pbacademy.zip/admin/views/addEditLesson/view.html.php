<?php

/**
 * Description of view
 * @property []LessonSeries $AllSeries 
 * @property []_category $AllCategories 
 * @property Lesson $Lesson
 * @author jfalkenstein
 */
class PbAcademyViewAddEditLesson extends BaseAdminViewMaster {
    
    public $AllSeries;
    public $AllCategories;
    public $Lesson;
    
    public function display($tpl = null) {
        $this->AllCategories = $this->get('AllCategories');
        $this->AllSeries = $this->get('AllSeries');
        $this->Lesson = $this->get('Lesson');
        $problem = false;
        parent::displayModel($problem);
    }
    
    protected function setPageTitle() {
        if(is_null($this->Lesson)){
            $this->PageTitle = 'Add New Lesson';
        }else{
            $this->PageTitle = 'Update Lesson: ' . $this->Lesson->Title;
        }
    }
}
