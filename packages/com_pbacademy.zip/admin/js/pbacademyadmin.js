var loadJSON = function(path, success, error){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status===200){
              if(success){
                  success(JSON.parse(xhr.responseText));
              }  
            }else{
                if(error){
                    error(xhr);
                }
            }
        }
    };
    xhr.open("GET",path,true);
    xhr.send();
}

var fillTableFromCBU = function(path, divId){
    hideLoadLink(divId);
    displayLoadingImage(divId);
    loadJSON(
            path,
            function(lessons){
                var div = document.getElementById(divId);
                var table = document.createElement('table');
                table.className += ' listTable';
                for(var key in lessons){
                    var row = table.insertRow(key);
                    row.innerHTML =
                            '<td>' + lessons[key].Title + '</td>' +
                            '<td>' + lessons[key].Id + '</td>' +
                            '<td>' + lessons[key].Category.Name + '</td>';
                }
                var header = table.createTHead(); 
                var row = header.insertRow(0);
                row.innerHTML =  '<th>Lesson Title</th>' +
                                '<th>Id</th>' +
                                '<th>Category Name</th>'; 
                hideLoadingImage(divId);
                div.appendChild(table);
            }
    );
}

var hideLoadLink = function (divId){
    var div = document.getElementById(divId);
    var link = div.getElementsByClassName('loadLink')[0];
    link.style.display = 'none';
}

var displayLoadingImage = function(divId){
    var div = document.getElementById(divId);
    var img = document.createElement('img');
    img.src = '/administrator/components/com_pbacademy/images/loading.gif';
    img.id = 'loading';
    img.style.width = '50px';
    div.appendChild(img);
}
var hideLoadingImage = function(divId){
    var div = document.getElementById(divId);
    var img = document.getElementById('loading');
    div.removeChild(img);
}

var tabToggle = function(idClicked){
    var buttons = document.getElementsByClassName('menuBarButton');
    for(i=0; i < buttons.length; i++){
        if(buttons[i].id == idClicked){
            buttons[i].style.fontWeight = 'bold';
        }else{
            buttons[i].style.fontWeight = 'normal';
        }
    }
    switch(idClicked){
        case 'manageLessons':
            this.div = document.getElementById('lessonsDiv');
            break;
        case 'manageSeries':
            this.div = document.getElementById('seriesDiv');
            break;
        case 'manageCategories':
            this.div = document.getElementById('categoriesDiv');
            break;
        default:
            break;
    }
    var divs = document.getElementsByClassName('manageTab');
    for(i=0; i < divs.length; i++){
        if(divs[i].id == this.div.id){
            divs[i].style.display = 'block';
        }else{
            divs[i].style.display = 'none';
        }
    }
}

var setSeries = function(){
    var seriesDrop = document.getElementById('seriesDrop');
    var selectedId = seriesDrop.options[seriesDrop.selectedIndex].value;
    var selectedSeries = AllSeries[selectedId];
    var seriesPositionSelect = document.getElementById('seriesPosition');
    for(var i = 0; i < selectedSeries.LessonsCount + 1; i++){
        var opt = document.createElement('option');
        opt.value = i;
        if(i === 0){
            opt.innerHTML = '#1: Before ' + selectedSeries.Lessons[i].Title;
        }else if(i = selectedSeries.LessonsCount){
            opt.innerHTML = '#' + (i + 1) + 'At end of series.'
        }else{
            opt.innerHTML = '#' + (i + 1) + ': Before ' + selectedSeries.Lessons[i].Title;
        }
        seriesPositionSelect.add(opt, i);
    }
    var seriesOrderDiv = document.getElementById('SeriesOrder');
    seriesOrderDiv.style.display = 'block';
}