<?php


class PbAcademyModelCategories extends BaseModel{
    
}
