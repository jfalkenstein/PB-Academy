<?php /* @var $this NavBar */ ?>
<span class="icon-next navIcon"></span>
<a href="<?php echo $this->nextLesson->GetLink(); ?>">
    &nbsp;Next in Series: 
    <span class="nav-name">
        "<?php echo $this->nextLesson->Title ?>"
    </span>
</a>