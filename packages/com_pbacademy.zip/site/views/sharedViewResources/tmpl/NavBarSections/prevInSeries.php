<?php /* @var $this NavBar */ ?>
<span class="icon-previous navIcon"></span>
<a href="<?php echo $this->prevLesson->GetLink(); ?>">
    &nbsp;Previous in Series: 
    <span class="nav-name">
        "<?php echo $this->prevLesson->Title ?>"
    </span>
</a>