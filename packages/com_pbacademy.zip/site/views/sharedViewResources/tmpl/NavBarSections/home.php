<span class="icon-home-2 navIcon"></span>
<a href="<?php echo UrlMaker::Home() ?>">
    &nbsp;Return to P&B Academy Home
</a>