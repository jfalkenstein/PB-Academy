<?php /* @var $this NavBar */ ?>
<span class="icon-grid navIcon"></span>
<a href="<?php echo UrlMaker::Categories(); ?>">
    &nbsp;See All Schools 
</a>