<?php /* @var $this NavBar */ ?>
<span class="icon-grid navIcon"></span>
<a href="<?php echo $this->thisSeries->GetLink(); ?>">
    &nbsp;See more in the series 
    <span class="nav-name">
        "<?php echo $this->thisSeries->SeriesName; ?>"
    </span>
</a>