<?php /* @var $this NavBar */ ?>
<span class="icon-grid navIcon"></span>
<a href="<?php echo $this->thisCategory->GetLink(); ?>">
    &nbsp;See more from 
    <span class="nav-name">
        "<?php echo $this->thisCategory->Name ?>"
    </span>
</a>