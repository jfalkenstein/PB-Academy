<?php /* @var $this NavBar */ ?>
<span class="icon-grid navIcon"></span>
<a href="<?php echo UrlMaker::AllSeries(); ?>">
    &nbsp;See All Lesson Series
</a>