<?php

/**
 *
 * @author jfalkenstein
 */
interface INavBarView {
    public function SetNavBar();
    
    public function PrintNavBar();
}
