<?php

/**
 *
 * @author jfalkenstein
 */
interface IAllCategoriesView{
    const All_CATEGORIES_INCLUDE = '/../../sharedViewResources/tmpl/AllCategories.php';
    
    public function ShowDescriptions();
}
