<div class="AllCategories">
    <?php include __DIR__ . IAllCategoriesView::All_CATEGORIES_INCLUDE; ?>
</div>

