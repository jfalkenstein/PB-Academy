var hoverShadow = function(){
    var sboxes = document.getElementsByClassName('shadowbox');
    for(var i = 0; i < sboxes.length; i++){
        var sbox = sboxes[i];
        var superimpose = sbox.getElementsByClassName('superimpose')[0];
        if(typeof superimpose != 'undefined'){
            superimpose.style.opacity = ".4";
            superimpose.style.filter = "alpha(opacity=40)";
        }
        sbox.addEventListener('mouseenter',function(){
            this.style.boxShadow = '0 0 10px black';
            var superimpose = this.getElementsByClassName('superimpose')[0];
            if(typeof superimpose != 'undefined'){
                superimpose.style.opacity = "1";
                superimpose.style.filter = "alpha(opacity=100)";
            }
        });
        sbox.addEventListener('mouseleave',function(){
            this.style.boxShadow = 'none';
            var superimpose = this.getElementsByClassName('superimpose')[0];
            if(typeof superimpose != 'undefined'){
                superimpose.style.opacity = ".4";
                superimpose.style.filter = "alpha(opacity=40)";
            }
        });
    };
};

window.addEventListener('load',hoverShadow);