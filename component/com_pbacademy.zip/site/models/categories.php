<?php

/**
 * This is the model used for the all categories page. It does
 * not currently add any functionality to the BaseModel. 
 */
class PbAcademyModelCategories extends BaseModel{
    
}
