<?php

class PbAcademyModelAllseries extends BaseModel{
    
}
