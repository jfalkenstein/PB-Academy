<?php
/**
 * This is the model used for the all Series page. It does
 * not currently add any functionality to the BaseModel. 
 */
class PbAcademyModelAllseries extends BaseModel{
    
}
