<?php

/**
 *
 * @author jfalkenstein
 */
interface IRecentLessonsModel {
    public function getRecentLessons();
}
