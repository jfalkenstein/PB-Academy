<?php

/**
 * Basic interface for models that desire to display recent lessons.
 * @author jfalkenstein
 */
interface IRecentLessonsModel {
    public function getRecentLessons();
}
