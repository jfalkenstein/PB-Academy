<?php /* @var $this NavBar */ ?>
<div class="NavBar-tooltip">See all schools</div>
<span class="icon-grid navIcon"></span>
<a href="<?php echo UrlMaker::Categories(); ?>">
    All Schools
</a>
