<?php /* @var $this NavBar */ ?>
<div class="NavBar-tooltip">See more in the series <span class="nav-name">"<?php echo $this->thisSeries->SeriesName; ?>"</span></div>
<span class="icon-grid navIcon"></span>
<a href="<?php echo $this->thisSeries->GetLink(); ?>">
    Series
</a>