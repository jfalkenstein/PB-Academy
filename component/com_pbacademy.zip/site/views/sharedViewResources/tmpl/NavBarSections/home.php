<div class="NavBar-tooltip">Return to the P&B Academy home page</div>
<span class="icon-home-2 navIcon"></span>
<a href="<?php echo UrlMaker::Home() ?>">
    Home
</a>
