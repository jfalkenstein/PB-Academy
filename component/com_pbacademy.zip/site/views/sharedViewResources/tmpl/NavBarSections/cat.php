<?php /* @var $this NavBar */ ?>
<div class="NavBar-tooltip">See more from <span class="nav-name"><?php echo $this->thisCategory->Name ?></span></div>
<span class="icon-grid navIcon"></span>
<a href="<?php echo $this->thisCategory->GetLink(); ?>">
    School
</a>