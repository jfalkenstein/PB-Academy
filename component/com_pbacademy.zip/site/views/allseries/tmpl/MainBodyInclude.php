<div class="AllSeries">
    <?php include __DIR__ . IAllSeriesView::All_SERIES_INCLUDE; ?>
</div>
