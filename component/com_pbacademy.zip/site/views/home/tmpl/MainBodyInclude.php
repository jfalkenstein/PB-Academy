<?php 
    /* @var $this PbAcademyViewHome */
    include __DIR__ . IRecentLessonsView::RECENT_LESSON_INCLUDE;
?>
<div id="categories">
    <h2>Schools:</h2>
    <?php include __DIR__ . IAllCategoriesView::All_CATEGORIES_INCLUDE;  ?>
</div>