<?php 
/*
 * This is a section used to provide feedback on ajax calls on the edit views.
 */
?>
<div class="feedback" id="successfullySubmitted">
    <span id="successfulMessage"></span><br/>
    <button class="btn btn-default" id="continueEdit">Continue Editing Form</button>
    <button class="btn btn-default" id="reload">Add another</button>
</div>
<div class="feedback" id="errorInSubmission">
    An error was encountered while attempting to submit the form.<br/>
    <span id="errorMessage"></span>
</div>