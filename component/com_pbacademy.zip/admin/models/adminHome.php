<?php

class PbAcademyModelAdminHome extends BaseAdminModel
{
    
}

