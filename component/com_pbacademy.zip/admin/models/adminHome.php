<?php

/**
 * This model is for the adminHome view.
 * At this point, it doesn't provide any functionality not already provided
 * by the BaseAdminModel.
 */
class PbAcademyModelAdminHome extends BaseAdminModel
{
    
}

