<?php

/**
 * These are the required functions for a ContentTypesRepository
 * @author jfalkenstein
 */
interface IContentTypesRepository {
    public function GetAll();
}
