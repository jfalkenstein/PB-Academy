<?php

/**
 *
 * @author jfalkenstein
 */
interface IContentTypesRepository {
    public function GetAll();
}
