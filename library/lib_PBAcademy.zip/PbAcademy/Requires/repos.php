<?php
$base = __DIR__ . '/../Repositories/';

require_once $base . 'BaseJoomlaRepository.php';
require_once $base . 'CategoriesRepository.php';
require_once $base . 'ContentTypesRepository.php';
require_once $base . 'LessonsRepository.php';
require_once $base . 'SeriesRepository.php';
