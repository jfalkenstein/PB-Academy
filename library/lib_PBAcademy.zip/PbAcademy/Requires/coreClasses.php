<?php
$base = __DIR__ . '/../Core/';

require_once $base . 'Category.php';
require_once $base . 'Lesson.php';
require_once $base . 'LessonSeries.php';
require_once $base . 'ContentType.php';
require_once $base . 'LessonEmbedder.php';