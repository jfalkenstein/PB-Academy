<?php
$base = __DIR__ . '/../Interfaces/';

require_once $base . 'IRepository.php';
require_once $base . 'ICategoriesRepository.php';
require_once $base . 'IContentTypesRepository.php';
require_once $base . 'ILessonsRepository.php';
require_once $base . 'ISeriesRepository.php';
